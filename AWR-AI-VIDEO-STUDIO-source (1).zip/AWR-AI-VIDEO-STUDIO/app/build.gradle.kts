plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "app.awr.studio"
    compileSdk = 34

    defaultConfig {
        applicationId = "app.awr.studio"
        minSdk = 29                       // Android 10+: needed for saving to the gallery without storage permissions
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }   // keeps the APK small (drops x86)
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // Signed with the auto-generated debug key so the release APK installs on your own phone.
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    lint { abortOnError = false; checkReleaseBuilds = false }   // Media3's @UnstableApi is a lint-only opt-in
    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.activity:activity-compose:1.9.1")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.4")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")

    // Native Android video editing / export (Apache-2.0, no native binaries, no licence fees)
    val media3 = "1.4.1"
    implementation("androidx.media3:media3-common:$media3")
    implementation("androidx.media3:media3-transformer:$media3")
    implementation("androidx.media3:media3-effect:$media3")
    implementation("androidx.media3:media3-exoplayer:$media3")
    implementation("androidx.media3:media3-ui:$media3")
    implementation("com.google.guava:guava:33.2.1-android")

    // Offline speech recognition for automatic subtitles (Apache-2.0). Needs a model file you import.
    implementation("net.java.dev.jna:jna:5.13.0@aar")
    implementation("com.alphacephei:vosk-android:0.3.47")

    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
