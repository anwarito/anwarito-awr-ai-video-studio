package app.awr.studio

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.suspendCancellableCoroutine
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File
import java.util.Locale
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean
import java.util.zip.ZipInputStream
import kotlin.coroutines.resume

/** Arabic voice-over using the voice already installed in Android. Free, offline when the voice data is installed. */
class ArabicTts(private val ctx: Context) {
    private var tts: TextToSpeech? = null

    suspend fun init(): Boolean = suspendCancellableCoroutine { c ->
        val done = AtomicBoolean(false)
        tts = TextToSpeech(ctx) { status ->
            val ok = status == TextToSpeech.SUCCESS && tts?.let {
                val r = it.setLanguage(Locale("ar"))
                r == TextToSpeech.LANG_AVAILABLE || r == TextToSpeech.LANG_COUNTRY_AVAILABLE || r == TextToSpeech.LANG_COUNTRY_VAR_AVAILABLE
            } == true
            if (done.compareAndSet(false, true)) c.resume(ok)
        }
    }

    suspend fun synth(text: String, out: File): Boolean = suspendCancellableCoroutine { c ->
        val t = tts
        if (t == null) { c.resume(false); return@suspendCancellableCoroutine }
        val done = AtomicBoolean(false)
        fun finish(v: Boolean) { if (done.compareAndSet(false, true)) c.resume(v) }
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) = finish(true)
            @Deprecated("Deprecated in Java") override fun onError(utteranceId: String?) = finish(false)
        })
        val limit = TextToSpeech.getMaxSpeechInputLength() - 1
        val r = t.synthesizeToFile(text.take(limit), Bundle(), out, UUID.randomUUID().toString())
        if (r != TextToSpeech.SUCCESS) finish(false)
    }

    fun shutdown() { tts?.shutdown() }
}

/** Offline speech recognition with a Vosk model you import once. EXPERIMENTAL. */
object VoskTranscriber {
    fun modelDir(ctx: Context) = File(ctx.filesDir, "models/vosk")
    fun installed(ctx: Context): Boolean = File(modelDir(ctx), "am").exists()

    /** Unzips a Vosk model archive into private storage, removing the single top-level folder. */
    fun importModel(ctx: Context, input: java.io.InputStream) {
        val dest = modelDir(ctx).apply { deleteRecursively(); mkdirs() }
        ZipInputStream(input.buffered()).use { z ->
            var e = z.nextEntry
            while (e != null) {
                val rel = e.name.substringAfter('/', "")
                if (rel.isNotEmpty() && !rel.contains("..")) {
                    val f = File(dest, rel)
                    if (e.isDirectory) f.mkdirs() else { f.parentFile?.mkdirs(); f.outputStream().use { z.copyTo(it) } }
                }
                e = z.nextEntry
            }
        }
    }

    fun transcribe(ctx: Context, audioOrVideo: File, onStatus: (String) -> Unit): List<Cue> {
        onStatus("Loading speech model…")
        val model = Model(modelDir(ctx).path)
        val rec = Recognizer(model, 16000f).apply { setWords(true) }
        val words = ArrayList<Triple<Long, Long, String>>()
        fun collect(json: String) {
            val arr = JSONObject(json).optJSONArray("result") ?: return
            for (i in 0 until arr.length()) {
                val w = arr.getJSONObject(i)
                words.add(Triple((w.getDouble("start") * 1000).toLong(), (w.getDouble("end") * 1000).toLong(), w.getString("word")))
            }
        }
        try {
            var pos = 0.0; var idx = 0L; var ratio = 1.0; var chunkFill = 0
            val buf = ByteArray(8000)
            AudioDecoder.decode(audioOrVideo, 15 * 60_000L) { data, n, sr, ch ->
                ratio = sr / 16000.0
                var i = 0
                while (i + ch <= n) {
                    var m = 0; for (c in 0 until ch) m += data[i + c]
                    val s = (m / ch).toShort()
                    while (pos <= idx) {                       // nearest-sample resampling to 16 kHz mono
                        buf[chunkFill++] = (s.toInt() and 0xFF).toByte(); buf[chunkFill++] = (s.toInt() shr 8).toByte()
                        pos += ratio
                        if (chunkFill >= buf.size) {
                            if (rec.acceptWaveForm(buf, chunkFill)) collect(rec.result)
                            chunkFill = 0
                        }
                    }
                    idx++; i += ch
                }
                onStatus("Recognising speech… ${idx / sr.coerceAtLeast(1)} s processed")
            }
            collect(rec.finalResult)
        } finally { rec.close(); model.close() }
        // Group words into subtitle lines: at most 7 words, or break on a pause longer than 0.8 s.
        val cues = ArrayList<Cue>()
        var cur = ArrayList<Triple<Long, Long, String>>()
        fun flush() { if (cur.isNotEmpty()) { cues.add(Cue(cur.first().first, cur.last().second, cur.joinToString(" ") { it.third })); cur = ArrayList() } }
        for (w in words) {
            if (cur.isNotEmpty() && (cur.size >= 7 || w.first - cur.last().second > 800)) flush()
            cur.add(w)
        }
        flush()
        return cues
    }
}
