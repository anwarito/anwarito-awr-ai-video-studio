@file:OptIn(ExperimentalMaterial3Api::class)

package app.awr.studio

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import java.io.File

@UnstableApi
@Composable
fun Root(vm: StudioVM) {
    BackHandler(vm.screen != Screen.Home) { vm.screen = if (vm.screen == Screen.Project) Screen.Home else Screen.Home }
    when (vm.screen) {
        Screen.Home -> HomeScreen(vm)
        Screen.Project -> ProjectScreen(vm)
        Screen.Caps -> CapsScreen(vm)
        Screen.Settings -> SettingsScreen(vm)
    }
}

// ---------- shared pieces ----------
@Composable
fun Page(title: String, onBack: (() -> Unit)?, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().cinematic().statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            if (onBack != null) TextButton(onClick = onBack) { Text("← Back") }
            Text(title, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 6.dp))
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)) { content(); Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
fun Section(title: String, tag: String? = null, content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(title, fontWeight = FontWeight.SemiBold)
                if (tag != null) Pill(tag)
            }
            content()
        }
    }
}

@Composable
fun Pill(text: String, color: Color = Violet) =
    Text(text, color = color, fontSize = 11.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.clip(RoundedCornerShape(99.dp)).background(color.copy(alpha = .16f)).padding(horizontal = 8.dp, vertical = 2.dp))

@Composable
fun GradButton(text: String, enabled: Boolean = true, onClick: () -> Unit) =
    Box(Modifier.alpha(if (enabled) 1f else .4f).clip(RoundedCornerShape(12.dp))
        .background(Brush.horizontalGradient(listOf(Violet, Azure))).clickable(enabled = enabled, onClick = onClick)
        .padding(horizontal = 18.dp, vertical = 12.dp)) { Text(text, color = Color.White, fontWeight = FontWeight.Bold) }

@Composable
fun Note(t: String, color: Color = TextLo) = Text(t, color = color, fontSize = 13.sp, lineHeight = 18.sp)

@Composable
fun StatusBar(vm: StudioVM) {
    if (vm.status.isNotBlank() || vm.busy) Section("Status") {
        Note(vm.status, if (vm.status.startsWith("Error") || vm.status.contains("failed")) Bad else TextHi)
        if (vm.busy) {
            if (vm.progress >= 0f) LinearProgressIndicator(progress = { vm.progress }, modifier = Modifier.fillMaxWidth())
            else LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            TextButton(onClick = { vm.cancelTask() }) { Text("Cancel", color = Bad) }
        }
    }
}

// ---------- home ----------
@Composable
fun HomeScreen(vm: StudioVM) {
    Column(Modifier.fillMaxSize().cinematic().statusBarsPadding().navigationBarsPadding().padding(20.dp)) {
        Text("AWR", fontSize = 14.sp, color = TextLo, letterSpacing = 8.sp)
        Text("AI VIDEO STUDIO", style = TextStyle(brush = Brush.linearGradient(listOf(Violet, Azure)), fontSize = 30.sp, fontWeight = FontWeight.Black))
        Spacer(Modifier.height(4.dp))
        val r = vm.report
        Note("${r.ramMb} MB RAM · ${r.abi} · Android ${r.sdk} · ${r.freeStorageMb / 1024} GB free · private, offline, no ads")
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GradButton("New project") { vm.newProject() }
            OutlinedButton(onClick = { vm.screen = Screen.Caps }) { Text("What runs here?") }
            OutlinedButton(onClick = { vm.screen = Screen.Settings }) { Text("Settings") }
        }
        Spacer(Modifier.height(18.dp))
        Text("Projects (saved on this phone)", fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        if (vm.projects.isEmpty()) Note("No projects yet.")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(vm.projects, key = { it.id }) { p ->
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().clickable { vm.open(p) }) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(p.name, fontWeight = FontWeight.SemiBold)
                            Note("${p.clips.size} clips · ${p.ratio} · ${p.filter}")
                        }
                        TextButton(onClick = { vm.delete(p) }) { Text("Delete", color = Bad) }
                    }
                }
            }
        }
    }
}

// ---------- capabilities ----------
@Composable
fun CapsScreen(vm: StudioVM) = Page("What runs on this phone", { vm.screen = Screen.Home }) {
    Note("Decided from this phone's real hardware. Nothing below is simulated: features that cannot run are marked, with the reason.")
    vm.capabilities().forEach { c ->
        val (label, color) = when (c.mode) {
            Mode.LOCAL -> "ON THIS PHONE" to Ok; Mode.EXPERIMENTAL -> "EXPERIMENTAL" to Warn
            Mode.PC -> "ON YOUR PC" to Azure; Mode.UNAVAILABLE -> "NOT AVAILABLE" to Bad
        }
        Section(c.title, label) {
            Note(c.reason)
            if (c.alternative.isNotBlank()) Note("Free alternative: ${c.alternative}", TextHi)
        }
    }
}

// ---------- settings ----------
@Composable
fun SettingsScreen(vm: StudioVM) = Page("Settings", { vm.screen = Screen.Home }) {
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) vm.importSpeechModel(u) }
    Section("Speech model for subtitles", "EXPERIMENTAL") {
        Note(if (vm.voskReady) "A speech model is installed." else "Download a free Vosk model .zip once (alphacephei.com/vosk/models), then import it here. Arabic models are hundreds of MB; choose the smallest that fits and check it works on your phone.")
        GradButton("Import model (.zip)", !vm.busy) { pick.launch(arrayOf("application/zip", "application/octet-stream")) }
    }
    var url by remember { mutableStateOf(vm.prefs.pcUrl) }
    var ckpt by remember { mutableStateOf(vm.prefs.ckpt) }
    var t2v by remember { mutableStateOf(vm.prefs.wfT2V) }
    var i2v by remember { mutableStateOf(vm.prefs.wfI2V) }
    Section("Private PC link", "OPTIONAL") {
        Note("Leave empty to keep the app fully offline. Only if you own a PC running ComfyUI: enter its address to unlock AI image / text-to-video / image-to-video. Traffic is plain HTTP, so use your home Wi-Fi or a private VPN.")
        OutlinedTextField(url, { url = it; vm.prefs.pcUrl = it.trim() }, label = { Text("ComfyUI address, e.g. http://192.168.1.20:8188") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(ckpt, { ckpt = it; vm.prefs.ckpt = it.trim() }, label = { Text("Image checkpoint file name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(t2v, { t2v = it; vm.prefs.wfT2V = it }, label = { Text("Text-to-video workflow (API-format JSON)") }, minLines = 3, maxLines = 6, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(i2v, { i2v = it; vm.prefs.wfI2V = it }, label = { Text("Image-to-video workflow (API-format JSON)") }, minLines = 3, maxLines = 6, modifier = Modifier.fillMaxWidth())
        Note("Placeholders you can use in the JSON: {{PROMPT}} {{NEGATIVE}} {{IMAGE}} {{CKPT}} inside quotes; {{SEED}} {{WIDTH}} {{HEIGHT}} {{FRAMES}} as bare numbers.")
        GradButton("Test connection", !vm.busy && url.isNotBlank()) { vm.testPc() }
        if (vm.pcOnline != null) Note(if (vm.pcOnline == true) "Reachable." else "Not reachable.", if (vm.pcOnline == true) Ok else Bad)
    }
    StatusBar(vm)
}

// ---------- project ----------
private val TABS = listOf("Media", "AI", "Audio", "Style", "Export")

@Composable
fun ProjectScreen(vm: StudioVM) {
    val p = vm.current ?: run { vm.screen = Screen.Home; return }
    var tab by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize().cinematic().statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { vm.screen = Screen.Home }) { Text("←") }
            OutlinedTextField(p.name, { n -> vm.update { it.copy(name = n) } }, singleLine = true, modifier = Modifier.weight(1f))
        }
        ScrollableTabRow(selectedTabIndex = tab, containerColor = Color.Transparent, edgePadding = 8.dp) {
            TABS.forEachIndexed { i, t -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) }) }
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            when (tab) {
                0 -> MediaTab(vm, p); 1 -> AiTab(vm, p); 2 -> AudioTab(vm, p); 3 -> StyleTab(vm, p); else -> ExportTab(vm, p)
            }
            StatusBar(vm)
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
fun MediaTab(vm: StudioVM, p: Project) {
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { vm.importMedia(it) }
    Section("Clips (${p.clips.size})") {
        GradButton("Add videos / photos", !vm.busy) { pick.launch(arrayOf("video/*", "image/*")) }
        Note("Files are copied into this project so it stays complete and private. Videos keep their sound only if you turn it on in Style.")
        if (p.clips.isEmpty()) Note("No clips yet.")
        p.clips.forEachIndexed { i, c ->
            Card(colors = CardDefaults.cardColors(containerColor = Panel2), shape = RoundedCornerShape(12.dp)) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("${i + 1}. ${File(c.path).name.substringAfter('_')}", maxLines = 1, fontSize = 14.sp)
                    Note("${if (c.isImage) "Photo" else "Video"} · %.1f s".format(c.lenMs / 1000.0))
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = { vm.moveClip(i, -1) }) { Text("↑") }
                        TextButton(onClick = { vm.moveClip(i, 1) }) { Text("↓") }
                        if (c.isImage) {
                            TextButton(onClick = { vm.setClip(i) { it.copy(endMs = (it.endMs - 500).coerceAtLeast(1000)) } }) { Text("−0.5s") }
                            TextButton(onClick = { vm.setClip(i) { it.copy(endMs = it.endMs + 500) } }) { Text("+0.5s") }
                        } else {
                            TextButton(onClick = { vm.setClip(i) { it.copy(endMs = (it.endMs - 500).coerceAtLeast(it.startMs + 500)) } }) { Text("End −0.5s") }
                            TextButton(onClick = { vm.setClip(i) { it.copy(endMs = (it.endMs + 500).coerceAtMost(it.srcMs)) } }) { Text("End +0.5s") }
                        }
                        Spacer(Modifier.weight(1f))
                        TextButton(onClick = { vm.removeClip(i) }) { Text("Remove", color = Bad) }
                    }
                    if (c.isImage) Row(verticalAlignment = Alignment.CenterVertically) {
                        Switch(c.kenBurns, { on -> vm.setClip(i) { it.copy(kenBurns = on) } }); Spacer(Modifier.width(8.dp)); Note("Zoom / pan motion (not AI)")
                    }
                }
            }
        }
    }
    Section("Cut on the beat", "REAL AUDIO ANALYSIS") {
        Note(if (p.musicPath == null) "Add music in the Audio tab first." else "Re-times every clip so cuts land on the detected beats of your music.")
        GradButton("Sync cuts to music", !vm.busy && p.musicPath != null) { vm.syncBeats() }
    }
}

@Composable
fun AiTab(vm: StudioVM, p: Project) {
    var prompt by remember { mutableStateOf("") }
    val pc = vm.pcConfigured && vm.pcOnline != false
    Section("On this phone") {
        Note("AI image generation, text-to-video and image-to-video do not run on this phone (${"%.1f".format(vm.report.ramMb / 1024.0)} GB RAM). Open “What runs here?” on the home screen for the exact reasons. Nothing is faked.")
        Note("What you can do on the phone: photo motion, filters, Arabic voice-over, subtitles and beat-synced editing in the other tabs.", TextHi)
    }
    Section("Private PC (optional)", "OPTIONAL") {
        if (!vm.pcConfigured) Note("Not set up. This is the only route to AI generation, and it needs a computer you own running ComfyUI. Configure it in Settings; otherwise ignore this card.")
        OutlinedTextField(prompt, { prompt = it }, label = { Text("Describe the scene (English works best)") }, minLines = 2, modifier = Modifier.fillMaxWidth())
        GradButton("Generate cinematic image", pc && !vm.busy && prompt.isNotBlank()) { vm.genImage(prompt) }
        GradButton("Text → video", pc && !vm.busy && prompt.isNotBlank()) { vm.genVideo(prompt, null) }
        val firstImg = p.clips.firstOrNull { it.isImage }
        GradButton("Animate first photo → video", pc && !vm.busy && prompt.isNotBlank() && firstImg != null) { vm.genVideo(prompt, firstImg) }
    }
}

@Composable
fun AudioTab(vm: StudioVM, p: Project) {
    var text by remember { mutableStateOf("") }
    val pickMusic = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) vm.importMusic(u) }
    Section("Arabic voice-over", if (vm.ttsReady) "ON THIS PHONE" else "NEEDS VOICE DATA") {
        if (!vm.ttsReady) Note("No Arabic voice found. Install it: Android Settings > System > Languages > Text-to-speech.", Warn)
        OutlinedTextField(text, { text = it }, label = { Text("Narration / script") }, minLines = 3, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GradButton("Make voice-over", vm.ttsReady && !vm.busy) { vm.makeVoice(text) }
            OutlinedButton(onClick = { vm.scriptCues(text) }, enabled = text.isNotBlank()) { Text("Script → subtitles") }
        }
        if (p.voicePath != null) {
            Note("Voice-over attached. Volume ${(p.voiceVol * 100).toInt()}%")
            Slider(p.voiceVol, { v -> vm.update { it.copy(voiceVol = v) } }, valueRange = 0f..2f)
            OutlinedButton(onClick = { vm.fitImagesToVoice() }) { Text("Stretch photos to match voice") }
        }
    }
    Section("Music") {
        GradButton(if (p.musicPath == null) "Add music" else "Replace music", !vm.busy) { pickMusic.launch(arrayOf("audio/*")) }
        if (p.musicPath != null) { Note("Volume ${(p.musicVol * 100).toInt()}%  (loops to fit the video)"); Slider(p.musicVol, { v -> vm.update { it.copy(musicVol = v) } }, valueRange = 0f..1.5f) }
    }
    Section("Subtitles from speech", "EXPERIMENTAL") {
        Note(if (vm.voskReady) "Listens to the voice-over (or the first video) on the phone. Check the result; accuracy varies." else "Import a speech model in Settings to enable this.")
        GradButton("Transcribe", vm.voskReady && !vm.busy) { vm.transcribe() }
    }
    Section("Subtitle lines (${p.cues.size})") {
        if (p.cues.isEmpty()) Note("No subtitles yet.")
        p.cues.forEachIndexed { i, c ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Note("%.1f".format(c.startMs / 1000.0))
                OutlinedTextField(c.text, { t -> vm.update { q -> q.copy(cues = q.cues.mapIndexed { k, x -> if (k == i) x.copy(text = t) else x }) } },
                    modifier = Modifier.weight(1f).padding(horizontal = 6.dp))
                TextButton(onClick = { vm.update { q -> q.copy(cues = q.cues.filterIndexed { k, _ -> k != i }) } }) { Text("✕", color = Bad) }
            }
        }
    }
}

@Composable
fun StyleTab(vm: StudioVM, p: Project) {
    Section("Format") {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("9:16", "1:1", "16:9").forEach { r -> FilterChip(p.ratio == r, { vm.update { it.copy(ratio = r) } }, { Text(r) }) }
        }
    }
    Section("Cinematic filter") {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FILTERS.forEach { f -> FilterChip(p.filter == f, { vm.update { it.copy(filter = f) } }, { Text(f) }) }
        }
        Note("Filters are applied by the GPU during export. The preview player shows them after you export.")
    }
    Section("Options") {
        Row(verticalAlignment = Alignment.CenterVertically) { Switch(p.fade, { v -> vm.update { it.copy(fade = v) } }); Spacer(Modifier.width(8.dp)); Text("Fade through black between clips") }
        Row(verticalAlignment = Alignment.CenterVertically) { Switch(p.burnSubs, { v -> vm.update { it.copy(burnSubs = v) } }); Spacer(Modifier.width(8.dp)); Text("Burn subtitles into the video") }
        Row(verticalAlignment = Alignment.CenterVertically) { Switch(p.keepClipAudio, { v -> vm.update { it.copy(keepClipAudio = v) } }); Spacer(Modifier.width(8.dp)); Text("Keep original video sound") }
        Note("Original sound is only kept when all clips are videos and there is no voice-over or music.")
    }
}

@Composable
fun ExportTab(vm: StudioVM, p: Project) {
    val (w, h) = Exporter.canvas(p.ratio)
    Section("Export MP4") {
        Note("${w}×${h} H.264 + AAC, no watermark. Export runs in real time on the phone's hardware encoder and is capped at 720p to protect 4 GB devices. Keep the app open and the screen on.")
        GradButton("Export", !vm.busy && p.clips.isNotEmpty()) { vm.export() }
    }
    val f = vm.exported
    if (f != null && f.exists()) Section("Result") {
        val ctx = LocalContext.current
        val player = remember(f.path) { ExoPlayer.Builder(ctx).build().apply { setMediaItem(MediaItem.fromUri(android.net.Uri.fromFile(f))); prepare() } }
        DisposableEffect(player) { onDispose { player.release() } }
        AndroidView(factory = { PlayerView(it).apply { this.player = player } }, modifier = Modifier.fillMaxWidth().height(380.dp))
        GradButton("Save to gallery (Movies/AWR Studio)", !vm.busy) { vm.saveToGallery() }
    }
}
