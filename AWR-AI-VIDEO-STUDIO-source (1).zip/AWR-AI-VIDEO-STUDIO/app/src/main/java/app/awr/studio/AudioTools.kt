package app.awr.studio

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import java.io.File
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Decodes any audio track to PCM16 and hands it to [sink] in chunks. Streaming, so memory stays small. */
object AudioDecoder {
    fun decode(file: File, maxMs: Long, sink: (ShortArray, Int, Int, Int) -> Unit) {   // data, count, sampleRate, channels
        val ex = MediaExtractor()
        ex.setDataSource(file.path)
        val idx = (0 until ex.trackCount).firstOrNull {
            ex.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true
        } ?: run { ex.release(); throw IllegalStateException("No audio track in ${file.name}") }
        ex.selectTrack(idx)
        val fmt = ex.getTrackFormat(idx)
        val codec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
        codec.configure(fmt, null, null, 0)
        codec.start()
        val info = MediaCodec.BufferInfo()
        var sr = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        var ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        var inDone = false
        var outDone = false
        try {
            while (!outDone) {
                if (!inDone) {
                    val i = codec.dequeueInputBuffer(10_000)
                    if (i >= 0) {
                        val buf = codec.getInputBuffer(i)!!
                        val n = ex.readSampleData(buf, 0)
                        if (n < 0 || ex.sampleTime > maxMs * 1000) {
                            codec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true
                        } else {
                            codec.queueInputBuffer(i, 0, n, ex.sampleTime, 0); ex.advance()
                        }
                    }
                }
                val o = codec.dequeueOutputBuffer(info, 10_000)
                when {
                    o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val f = codec.outputFormat
                        sr = f.getInteger(MediaFormat.KEY_SAMPLE_RATE); ch = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    }
                    o >= 0 -> {
                        val out = codec.getOutputBuffer(o)!!
                        out.position(info.offset); out.limit(info.offset + info.size)
                        val sb = out.order(java.nio.ByteOrder.nativeOrder()).asShortBuffer()
                        val arr = ShortArray(sb.remaining()); sb.get(arr)
                        if (arr.isNotEmpty()) sink(arr, arr.size, sr, ch)
                        codec.releaseOutputBuffer(o, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                    }
                }
            }
        } finally {
            runCatching { codec.stop() }; codec.release(); ex.release()
        }
    }
}

object BeatDetector {
    /** Returns beat/onset times in ms (energy-flux peak picking). Analyses at most [maxMs] of the track. */
    fun detect(file: File, maxMs: Long = 90_000): List<Long> {
        val energies = ArrayList<Float>()
        var acc = 0.0; var cnt = 0; var hop = 0
        AudioDecoder.decode(file, maxMs) { data, n, sr, ch ->
            if (hop == 0) hop = sr / 50                       // 20 ms frames
            var i = 0
            while (i + ch <= n) {
                var m = 0.0
                for (c in 0 until ch) m += data[i + c]
                m /= ch
                acc += m * m; cnt++
                if (cnt >= hop) { energies.add(Math.sqrt(acc / cnt).toFloat()); acc = 0.0; cnt = 0 }
                i += ch
            }
        }
        if (energies.size < 30) return emptyList()
        val flux = FloatArray(energies.size) { if (it == 0) 0f else max(0f, energies[it] - energies[it - 1]) }
        val beats = ArrayList<Long>()
        var last = -100
        for (i in 5 until flux.size - 1) {
            val a = max(0, i - 25); val b = min(flux.size, i + 25)
            var mean = 0f; for (k in a until b) mean += flux[k]; mean /= (b - a)
            if (flux[i] > mean * 1.6f + 1f && flux[i] >= flux[i - 1] && flux[i] >= flux[i + 1] && i - last >= 15) {
                beats.add(i * 20L); last = i
            }
        }
        return beats
    }

    /** Splits [totalMs] into [n] clip lengths whose boundaries sit on the nearest detected beat. */
    fun beatLengths(beats: List<Long>, n: Int, totalMs: Long): List<Long> {
        val bounds = mutableListOf(0L)
        for (k in 1 until n) {
            val target = totalMs * k / n
            val b = beats.minByOrNull { abs(it - target) } ?: target
            bounds += max(b, bounds.last() + 600)
        }
        bounds += max(totalMs, bounds.last() + 600)
        return bounds.zipWithNext { a, b -> b - a }
    }
}

object Subtitles {
    /** Splits a script into short lines and times them proportionally to their length across [totalMs]. */
    fun fromScript(text: String, totalMs: Long, offsetMs: Long = 0): List<Cue> {
        val parts = text.split(Regex("(?<=[.!?؟…])\\s+|\\n+")).map { it.trim() }.filter { it.isNotEmpty() }
        val lines = parts.flatMap { p -> p.split(Regex("\\s+")).chunked(7).map { it.joinToString(" ") } }
        if (lines.isEmpty() || totalMs <= 0) return emptyList()
        val w = lines.map { max(8, it.length) }
        val sum = w.sum().toDouble()
        var acc = 0
        return lines.mapIndexed { i, t ->
            val s = offsetMs + (totalMs * acc / sum).toLong(); acc += w[i]
            val e = offsetMs + (totalMs * acc / sum).toLong()
            Cue(s, max(s + 400, e - 60), t)
        }
    }

    fun activeAt(cues: List<Cue>, ms: Long): Cue? = cues.firstOrNull { ms in it.startMs..it.endMs }
}
