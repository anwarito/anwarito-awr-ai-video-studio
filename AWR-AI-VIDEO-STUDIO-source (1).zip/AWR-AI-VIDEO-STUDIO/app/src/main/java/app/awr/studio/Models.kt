package app.awr.studio

import android.content.Context
import android.media.MediaMetadataRetriever
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

data class Clip(
    val id: String = UUID.randomUUID().toString(),
    val path: String,
    val isImage: Boolean,
    val srcMs: Long,          // full length of the source (videos) or default length (images)
    val startMs: Long,
    val endMs: Long,
    val kenBurns: Boolean = true
) {
    val lenMs get() = endMs - startMs
}

data class Cue(val startMs: Long, val endMs: Long, val text: String)

data class Project(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Untitled project",
    val ratio: String = "9:16",            // "9:16", "16:9", "1:1"
    val filter: String = "none",
    val clips: List<Clip> = emptyList(),
    val cues: List<Cue> = emptyList(),
    val voicePath: String? = null,
    val musicPath: String? = null,
    val voiceVol: Float = 1f,
    val musicVol: Float = 0.35f,
    val fade: Boolean = true,
    val burnSubs: Boolean = true,
    val keepClipAudio: Boolean = false,
    val updated: Long = System.currentTimeMillis()
)

fun durationOf(f: File): Long = try {
    val r = MediaMetadataRetriever()
    r.setDataSource(f.path)
    val d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
    r.release(); d
} catch (e: Exception) { 0L }

private fun Project.toJson(): JSONObject = JSONObject().apply {
    put("id", id); put("name", name); put("ratio", ratio); put("filter", filter)
    put("voice", voicePath ?: ""); put("music", musicPath ?: "")
    put("voiceVol", voiceVol.toDouble()); put("musicVol", musicVol.toDouble())
    put("fade", fade); put("burn", burnSubs); put("keepAudio", keepClipAudio); put("updated", updated)
    put("clips", JSONArray(clips.map {
        JSONObject().put("id", it.id).put("path", it.path).put("img", it.isImage)
            .put("src", it.srcMs).put("s", it.startMs).put("e", it.endMs).put("kb", it.kenBurns)
    }))
    put("cues", JSONArray(cues.map { JSONObject().put("s", it.startMs).put("e", it.endMs).put("t", it.text) }))
}

private fun projectFromJson(j: JSONObject): Project {
    val clips = j.getJSONArray("clips").let { a ->
        (0 until a.length()).map {
            val c = a.getJSONObject(it)
            Clip(c.getString("id"), c.getString("path"), c.getBoolean("img"), c.getLong("src"),
                c.getLong("s"), c.getLong("e"), c.optBoolean("kb", true))
        }
    }
    val cues = j.getJSONArray("cues").let { a ->
        (0 until a.length()).map { val c = a.getJSONObject(it); Cue(c.getLong("s"), c.getLong("e"), c.getString("t")) }
    }
    return Project(
        id = j.getString("id"), name = j.getString("name"), ratio = j.getString("ratio"), filter = j.getString("filter"),
        clips = clips, cues = cues,
        voicePath = j.optString("voice").ifBlank { null }, musicPath = j.optString("music").ifBlank { null },
        voiceVol = j.optDouble("voiceVol", 1.0).toFloat(), musicVol = j.optDouble("musicVol", .35).toFloat(),
        fade = j.optBoolean("fade", true), burnSubs = j.optBoolean("burn", true),
        keepClipAudio = j.optBoolean("keepAudio", false), updated = j.optLong("updated")
    )
}

/** Every project lives in the app's private storage: filesDir/projects/<id>/ */
class ProjectStore(ctx: Context) {
    private val root = File(ctx.filesDir, "projects").apply { mkdirs() }
    fun dir(id: String) = File(root, id).apply { mkdirs() }
    fun mediaDir(id: String) = File(dir(id), "media").apply { mkdirs() }
    fun exportDir(id: String) = File(dir(id), "export").apply { mkdirs() }
    fun save(p: Project) { File(dir(p.id), "project.json").writeText(p.toJson().toString(2)) }
    fun delete(id: String) { dir(id).deleteRecursively() }
    fun list(): List<Project> = root.listFiles().orEmpty().mapNotNull {
        runCatching { projectFromJson(JSONObject(File(it, "project.json").readText())) }.getOrNull()
    }.sortedByDescending { it.updated }
}

/** Settings. The PC fields are optional and empty by default. */
class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("awr", Context.MODE_PRIVATE)
    private fun s(k: String, d: String = "") = sp.getString(k, d) ?: d
    private fun put(k: String, v: String) = sp.edit().putString(k, v).apply()
    var pcUrl: String get() = s("pc"); set(v) = put("pc", v)
    var ckpt: String get() = s("ckpt", "v1-5-pruned-emaonly.safetensors"); set(v) = put("ckpt", v)
    var wfT2V: String get() = s("wft2v"); set(v) = put("wft2v", v)
    var wfI2V: String get() = s("wfi2v"); set(v) = put("wfi2v", v)
}
