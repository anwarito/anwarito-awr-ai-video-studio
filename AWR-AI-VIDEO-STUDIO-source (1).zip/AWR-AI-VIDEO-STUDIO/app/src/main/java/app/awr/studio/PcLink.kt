package app.awr.studio

import org.json.JSONObject
import java.io.DataOutputStream
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.UUID

/**
 * OPTIONAL. Talks to a ComfyUI server on a computer you own. Off by default; the app never touches the network unless
 * you enter an address in Settings. Used only for features the phone cannot run (image / text-to-video / image-to-video AI).
 */
class ComfyClient(base: String) {
    private val b = base.trim().trimEnd('/')
    data class Out(val filename: String, val subfolder: String, val type: String)

    private fun open(url: String, t: Int): HttpURLConnection =
        (URL(url).openConnection() as HttpURLConnection).apply { connectTimeout = t; readTimeout = t * 6 }

    private fun read(c: HttpURLConnection): String {
        val code = c.responseCode
        val body = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText().orEmpty()
        c.disconnect()
        if (code !in 200..299) throw IOException("HTTP $code: ${body.take(400)}")
        return body
    }

    fun ping(): Boolean = try { read(open("$b/system_stats", 4000)); true } catch (e: Exception) { false }

    fun uploadImage(f: File): String {
        val boundary = "----awr" + UUID.randomUUID()
        val c = open("$b/upload/image", 20000).apply {
            requestMethod = "POST"; doOutput = true
            setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary"); setChunkedStreamingMode(0)
        }
        val safe = f.name.replace(Regex("[^A-Za-z0-9._-]"), "_")
        DataOutputStream(c.outputStream).use { o ->
            o.writeBytes("--$boundary\r\nContent-Disposition: form-data; name=\"overwrite\"\r\n\r\ntrue\r\n")
            o.writeBytes("--$boundary\r\nContent-Disposition: form-data; name=\"image\"; filename=\"$safe\"\r\nContent-Type: application/octet-stream\r\n\r\n")
            f.inputStream().use { it.copyTo(o) }
            o.writeBytes("\r\n--$boundary--\r\n")
        }
        return JSONObject(read(c)).getString("name")
    }

    /** Queues a workflow (ComfyUI "Save (API Format)" JSON) and waits for it. */
    fun run(workflow: String, onStatus: (String) -> Unit, cancelled: () -> Boolean): List<Out> {
        val body = JSONObject().put("prompt", JSONObject(workflow)).put("client_id", UUID.randomUUID().toString()).toString()
        val post = open("$b/prompt", 15000).apply {
            requestMethod = "POST"; doOutput = true; setRequestProperty("Content-Type", "application/json")
        }
        post.outputStream.use { it.write(body.toByteArray()) }
        val id = JSONObject(read(post)).getString("prompt_id")
        val t0 = System.currentTimeMillis()
        while (true) {
            if (cancelled()) throw kotlinx.coroutines.CancellationException("cancelled")
            Thread.sleep(2000)
            val h = JSONObject(read(open("$b/history/$id", 8000)))
            if (h.has(id)) {
                val e = h.getJSONObject(id)
                if (e.optJSONObject("status")?.optString("status_str") == "error") throw IOException("ComfyUI reported an error. Check the server console.")
                val outs = e.getJSONObject("outputs"); val res = ArrayList<Out>()
                for (node in outs.keys()) for (key in listOf("images", "gifs", "videos")) {
                    val a = outs.getJSONObject(node).optJSONArray(key) ?: continue
                    for (i in 0 until a.length()) a.getJSONObject(i).let { res += Out(it.getString("filename"), it.optString("subfolder"), it.optString("type", "output")) }
                }
                return res
            }
            onStatus("Generating on your PC… ${(System.currentTimeMillis() - t0) / 1000}s")
        }
    }

    fun download(o: Out, dest: File) {
        val u = "$b/view?filename=${URLEncoder.encode(o.filename, "UTF-8")}&subfolder=${URLEncoder.encode(o.subfolder, "UTF-8")}&type=${o.type}"
        val c = open(u, 30000)
        if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
        c.inputStream.use { i -> dest.outputStream().use { i.copyTo(it) } }; c.disconnect()
    }

    companion object {
        /** Placeholders: {{PROMPT}} {{NEGATIVE}} (inside quotes), {{SEED}} {{WIDTH}} {{HEIGHT}} {{FRAMES}} (bare numbers), {{IMAGE}} {{CKPT}} (inside quotes). */
        const val DEFAULT_IMAGE_WF = """{"3":{"class_type":"KSampler","inputs":{"seed":{{SEED}},"steps":25,"cfg":7,"sampler_name":"euler","scheduler":"normal","denoise":1,"model":["4",0],"positive":["6",0],"negative":["7",0],"latent_image":["5",0]}},"4":{"class_type":"CheckpointLoaderSimple","inputs":{"ckpt_name":"{{CKPT}}"}},"5":{"class_type":"EmptyLatentImage","inputs":{"width":{{WIDTH}},"height":{{HEIGHT}},"batch_size":1}},"6":{"class_type":"CLIPTextEncode","inputs":{"text":"{{PROMPT}}","clip":["4",1]}},"7":{"class_type":"CLIPTextEncode","inputs":{"text":"{{NEGATIVE}}","clip":["4",1]}},"8":{"class_type":"VAEDecode","inputs":{"samples":["3",0],"vae":["4",2]}},"9":{"class_type":"SaveImage","inputs":{"filename_prefix":"awr","images":["8",0]}}}"""

        private fun esc(s: String) = JSONObject.quote(s).drop(1).dropLast(1)

        fun fill(wf: String, prompt: String, negative: String, seed: Long, w: Int, h: Int, frames: Int, image: String, ckpt: String) =
            wf.replace("{{PROMPT}}", esc(prompt)).replace("{{NEGATIVE}}", esc(negative))
                .replace("{{SEED}}", seed.toString()).replace("{{WIDTH}}", w.toString()).replace("{{HEIGHT}}", h.toString())
                .replace("{{FRAMES}}", frames.toString()).replace("{{IMAGE}}", esc(image)).replace("{{CKPT}}", esc(ckpt))
    }
}
