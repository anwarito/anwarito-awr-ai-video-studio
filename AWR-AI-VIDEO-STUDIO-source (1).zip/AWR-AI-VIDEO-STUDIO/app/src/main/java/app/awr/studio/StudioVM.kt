package app.awr.studio

import android.app.Application
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.util.UnstableApi
import androidx.media3.transformer.Transformer
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File
import kotlin.math.min

enum class Screen { Home, Project, Caps, Settings }

@UnstableApi
class StudioVM(app: Application) : AndroidViewModel(app) {
    private val ctx get() = getApplication<Application>()
    val store = ProjectStore(ctx)
    val prefs = Prefs(ctx)
    private val tts = ArabicTts(ctx)

    var screen by mutableStateOf(Screen.Home)
    var projects by mutableStateOf(store.list())
    var current by mutableStateOf<Project?>(null)
    var status by mutableStateOf("")
    var busy by mutableStateOf(false)
    var progress by mutableStateOf(-1f)
    var exported by mutableStateOf<File?>(null)
    var report by mutableStateOf(HardwareProbe.read(ctx))
    var ttsReady by mutableStateOf(false)
    var voskReady by mutableStateOf(VoskTranscriber.installed(ctx))
    var pcOnline by mutableStateOf<Boolean?>(null)
    private var cancel = false
    private var transformer: Transformer? = null

    init { viewModelScope.launch { ttsReady = tts.init() } }

    val pcConfigured get() = prefs.pcUrl.isNotBlank()
    fun capabilities() = HardwareProbe.capabilities(report, pcConfigured, ttsReady, voskReady)

    // ---------- projects ----------
    fun newProject() { val p = Project(); store.save(p); projects = store.list(); open(p) }
    fun open(p: Project) { current = p; exported = null; status = ""; screen = Screen.Project }
    fun delete(p: Project) { store.delete(p.id); projects = store.list() }
    fun update(block: (Project) -> Project) {
        val p = current ?: return
        val n = block(p).copy(updated = System.currentTimeMillis())
        current = n; store.save(n); projects = store.list()
    }

    private fun task(label: String, block: suspend () -> Unit) {
        if (busy) return
        busy = true; cancel = false; status = label; progress = -1f
        viewModelScope.launch(Dispatchers.IO) {
            try { block() }
            catch (e: CancellationException) { status = "Cancelled." }
            catch (e: Throwable) { status = "Error: ${e.message ?: e.javaClass.simpleName}" }
            finally { busy = false }
        }
    }
    fun cancelTask() { cancel = true; transformer?.cancel() }

    // ---------- media ----------
    private fun queryName(u: Uri): String? = ctx.contentResolver.query(u, null, null, null, null)?.use {
        if (it.moveToFirst()) it.getColumnIndex(OpenableColumns.DISPLAY_NAME).let { i -> if (i >= 0) it.getString(i) else null } else null
    }

    private fun copyIn(u: Uri, dir: File, fallback: String): File {
        val name = (queryName(u) ?: fallback).replace(Regex("[^\\p{L}\\p{N}._-]"), "_")
        val f = File(dir, "${System.currentTimeMillis()}_$name")
        ctx.contentResolver.openInputStream(u)!!.use { i -> f.outputStream().use { i.copyTo(it) } }
        return f
    }

    private fun addClip(f: File, image: Boolean) {
        val d = if (image) 3000L else durationOf(f).takeIf { it > 0 } ?: throw IllegalStateException("Cannot read this video")
        update { it.copy(clips = it.clips + Clip(path = f.path, isImage = image, srcMs = d, startMs = 0, endMs = d)) }
    }

    fun importMedia(uris: List<Uri>) {
        val p = current ?: return
        task("Copying media into the project…") {
            for (u in uris) {
                val img = ctx.contentResolver.getType(u)?.startsWith("image/") == true
                addClip(copyIn(u, store.mediaDir(p.id), if (img) "image" else "video"), img)
            }
            status = "Added ${uris.size} file(s)."
        }
    }

    fun importMusic(u: Uri) {
        val p = current ?: return
        task("Importing music…") {
            val f = copyIn(u, store.mediaDir(p.id), "music"); update { it.copy(musicPath = f.path) }; status = "Music added."
        }
    }

    fun moveClip(i: Int, d: Int) = update { p ->
        val l = p.clips.toMutableList(); val j = i + d
        if (j in l.indices) { val t = l[i]; l[i] = l[j]; l[j] = t }
        p.copy(clips = l)
    }
    fun removeClip(i: Int) = update { p -> p.copy(clips = p.clips.filterIndexed { k, _ -> k != i }) }
    fun setClip(i: Int, block: (Clip) -> Clip) = update { p -> p.copy(clips = p.clips.mapIndexed { k, c -> if (k == i) block(c) else c }) }

    // ---------- on-device audio features ----------
    fun makeVoice(text: String) {
        val p = current ?: return
        if (text.isBlank()) { status = "Write the narration text first."; return }
        task("Generating Arabic voice-over…") {
            val f = File(store.mediaDir(p.id), "voice_${System.currentTimeMillis()}.wav")
            if (!tts.synth(text, f)) { status = "The Arabic voice failed. Check the Android text-to-speech settings."; return@task }
            val d = durationOf(f)
            update { it.copy(voicePath = f.path, cues = Subtitles.fromScript(text, d)) }
            status = "Voice-over ready (${d / 1000}s). Subtitles were timed from the same text."
        }
    }

    fun scriptCues(text: String) {
        val p = current ?: return
        val total = p.voicePath?.let { durationOf(File(it)) } ?: p.clips.sumOf { it.lenMs }
        val cues = Subtitles.fromScript(text, total)
        update { it.copy(cues = cues) }; status = "${cues.size} subtitle lines added."
    }

    fun fitImagesToVoice() {
        val p = current ?: return
        val v = p.voicePath?.let { durationOf(File(it)) } ?: return
        val imgs = p.clips.count { it.isImage }; if (imgs == 0) return
        val vids = p.clips.filter { !it.isImage }.sumOf { it.lenMs }
        val each = ((v - vids) / imgs).coerceAtLeast(1500)
        update { q -> q.copy(clips = q.clips.map { if (it.isImage) it.copy(endMs = each) else it }) }
        status = "Photos now last ${each / 1000.0}s each to match the voice."
    }

    fun importSpeechModel(u: Uri) = task("Importing speech model… (can take a minute)") {
        ctx.contentResolver.openInputStream(u)!!.use { VoskTranscriber.importModel(ctx, it) }
        voskReady = VoskTranscriber.installed(ctx)
        status = if (voskReady) "Speech model installed." else "That zip is not a Vosk model (no 'am' folder)."
    }

    fun transcribe() {
        val p = current ?: return
        val src = p.voicePath ?: p.clips.firstOrNull { !it.isImage }?.path
        if (src == null) { status = "Add a voice-over or a video first."; return }
        if (!voskReady) { status = "Import a speech model in Settings first."; return }
        task("Starting speech recognition…") {
            val cues = VoskTranscriber.transcribe(ctx, File(src)) { status = it }
            update { it.copy(cues = cues) }
            status = if (cues.isEmpty()) "No speech was recognised." else "${cues.size} subtitle lines created (experimental)."
        }
    }

    fun syncBeats() {
        val p = current ?: return
        val m = p.musicPath ?: run { status = "Add music first."; return }
        if (p.clips.isEmpty()) { status = "Add clips first."; return }
        task("Listening for the beat…") {
            val beats = BeatDetector.detect(File(m))
            if (beats.size < 4) { status = "No clear beat found in this track."; return@task }
            val total = min(durationOf(File(m)), 60_000L).coerceAtLeast(p.clips.size * 800L)
            val lens = BeatDetector.beatLengths(beats, p.clips.size, total)
            update { q -> q.copy(clips = q.clips.mapIndexed { i, c ->
                if (c.isImage) c.copy(endMs = lens[i]) else c.copy(endMs = c.startMs + min(lens[i], c.srcMs - c.startMs))
            }) }
            status = "Cuts snapped to ${beats.size} detected beats."
        }
    }

    // ---------- optional private PC ----------
    fun testPc() = task("Contacting your PC…") {
        pcOnline = ComfyClient(prefs.pcUrl).ping(); status = if (pcOnline == true) "PC reachable." else "PC not reachable."
    }

    private fun sizeFor(ratio: String) = when (ratio) { "16:9" -> 1024 to 576; "1:1" -> 768 to 768; else -> 576 to 1024 }

    fun genImage(prompt: String) {
        val p = current ?: return
        task("Sending to your PC…") {
            val c = ComfyClient(prefs.pcUrl); val (w, h) = sizeFor(p.ratio)
            val wf = ComfyClient.fill(ComfyClient.DEFAULT_IMAGE_WF, "$prompt, cinematic lighting, film still, ultra detailed",
                "blurry, low quality, watermark, text", System.nanoTime() and 0xFFFFFFF, w, h, 1, "", prefs.ckpt)
            val o = c.run(wf, { status = it }, { cancel }).firstOrNull() ?: throw IllegalStateException("No output returned")
            val f = File(store.mediaDir(p.id), "gen_${System.currentTimeMillis()}.png"); c.download(o, f); addClip(f, true)
            status = "Image added."
        }
    }

    fun genVideo(prompt: String, fromImage: Clip?) {
        val p = current ?: return
        val wf = if (fromImage == null) prefs.wfT2V else prefs.wfI2V
        if (wf.isBlank()) { status = "Paste a ComfyUI workflow for this in Settings first."; return }
        task("Sending to your PC…") {
            val c = ComfyClient(prefs.pcUrl); val (w, h) = sizeFor(p.ratio)
            val img = fromImage?.let { c.uploadImage(File(it.path)) } ?: ""
            val body = ComfyClient.fill(wf, prompt, "blurry, low quality, watermark", System.nanoTime() and 0xFFFFFFF, w, h, 49, img, prefs.ckpt)
            val o = c.run(body, { status = it }, { cancel }).firstOrNull { it.filename.substringAfterLast('.').lowercase() in listOf("mp4", "webm", "mkv") }
                ?: throw IllegalStateException("The workflow did not output an MP4/WebM file")
            val f = File(store.mediaDir(p.id), "gen_${System.currentTimeMillis()}.${o.filename.substringAfterLast('.')}"); c.download(o, f); addClip(f, false)
            status = "Video clip added."
        }
    }

    // ---------- export ----------
    fun export() {
        val p = current ?: return
        if (p.clips.isEmpty()) { status = "Add at least one clip."; return }
        if (busy) return
        busy = true; progress = 0f; status = "Exporting… keep the app open."; exported = null
        val out = File(store.exportDir(p.id), "AWR_${System.currentTimeMillis()}.mp4")
        transformer = Exporter.start(ctx, p, out, { progress = it }) { err ->
            busy = false; progress = -1f
            if (err == null) { exported = out; status = "Export finished (${out.length() / 1048576} MB)." }
            else status = "Export failed: ${err.message}"
        }
    }

    fun saveToGallery() {
        val f = exported ?: return
        task("Saving to gallery…") {
            val ok = Exporter.saveToGallery(ctx, f, f.name) != null
            status = if (ok) "Saved to Movies/AWR Studio." else "Could not save to the gallery."
        }
    }

    override fun onCleared() { tts.shutdown() }
}
