package app.awr.studio

import androidx.compose.foundation.background
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

val Ink = Color(0xFF07060F)
val Panel = Color(0xFF110F24)
val Panel2 = Color(0xFF1B1838)
val Violet = Color(0xFF8B5CF6)
val Azure = Color(0xFF3B82F6)
val TextHi = Color(0xFFEDEBFF)
val TextLo = Color(0xFF9A96C4)
val Ok = Color(0xFF34D399)
val Warn = Color(0xFFFBBF24)
val Bad = Color(0xFFF87171)

@Composable
fun AwrTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = darkColorScheme(
        primary = Violet, secondary = Azure, background = Ink, surface = Panel,
        onPrimary = Color.White, onBackground = TextHi, onSurface = TextHi,
        surfaceVariant = Panel2, onSurfaceVariant = TextLo
    ),
    content = content
)

/** Dark ground with a violet glow top-left and a blue glow on the right edge. */
fun Modifier.cinematic(): Modifier = this.background(Ink).drawBehind {
    drawRect(Brush.radialGradient(listOf(Violet.copy(alpha = .36f), Color.Transparent), center = Offset(0f, 0f), radius = size.width * 1.1f))
    drawRect(Brush.radialGradient(listOf(Azure.copy(alpha = .26f), Color.Transparent), center = Offset(size.width, size.height * .38f), radius = size.width))
}
