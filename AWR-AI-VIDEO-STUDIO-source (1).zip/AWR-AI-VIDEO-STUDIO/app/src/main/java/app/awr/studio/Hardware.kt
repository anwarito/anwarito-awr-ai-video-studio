package app.awr.studio

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.StatFs

data class DeviceReport(
    val ramMb: Long, val availRamMb: Long, val cores: Int, val abi: String,
    val sdk: Int, val freeStorageMb: Long, val lowRam: Boolean
)

enum class Mode { LOCAL, EXPERIMENTAL, PC, UNAVAILABLE }

data class Capability(val title: String, val mode: Mode, val reason: String, val alternative: String = "")

object HardwareProbe {
    fun read(ctx: Context): DeviceReport {
        val am = ctx.getSystemService(ActivityManager::class.java)
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val st = StatFs(ctx.filesDir.path)
        return DeviceReport(
            ramMb = mi.totalMem / 1048576, availRamMb = mi.availMem / 1048576,
            cores = Runtime.getRuntime().availableProcessors(),
            abi = Build.SUPPORTED_ABIS.firstOrNull() ?: "?", sdk = Build.VERSION.SDK_INT,
            freeStorageMb = st.availableBytes / 1048576, lowRam = am.isLowRamDevice
        )
    }

    /** Decides, from the real hardware, what runs on this phone. Nothing here is simulated. */
    fun capabilities(r: DeviceReport, pcConfigured: Boolean, ttsArabic: Boolean, voskInstalled: Boolean): List<Capability> {
        val gb = "%.1f".format(r.ramMb / 1024.0)
        val heavyAlt = if (pcConfigured) "Your private PC is configured, so this runs there (Settings)."
        else "Optional: run it on a PC you own with ComfyUI (free) and link it in Settings. The phone alone cannot do it."
        val heavyMode = if (pcConfigured) Mode.PC else Mode.UNAVAILABLE
        return listOf(
            Capability("Video editing and MP4 export", Mode.LOCAL,
                "Android's built-in hardware codecs through Media3. Exports 720p-class H.264 with no watermark. This phone has $gb GB RAM, so export is capped at 720p to stay inside memory."),
            Capability("Cinematic filters, fade, 9:16 / 16:9 / 1:1", Mode.LOCAL,
                "Applied by the GPU during export. These are colour and crop effects, not AI."),
            Capability("Music beat sync", Mode.LOCAL,
                "Real audio analysis on the phone: it decodes the track, finds energy peaks, and snaps your cuts to them."),
            Capability("Arabic voice-over (text-to-speech)",
                if (ttsArabic) Mode.LOCAL else Mode.UNAVAILABLE,
                if (ttsArabic) "Uses the Arabic voice installed in Android. It works offline if the voice data is downloaded."
                else "No Arabic voice is installed on this phone.",
                if (ttsArabic) "" else "Android Settings > System > Languages > Text-to-speech > install Arabic voice data (free)."),
            Capability("Subtitles from a script", Mode.LOCAL,
                "Splits your text into lines and spreads them over the voice-over or video length. No AI involved."),
            Capability("Subtitles from speech (Vosk)",
                if (voskInstalled && r.ramMb >= 3000) Mode.EXPERIMENTAL else Mode.UNAVAILABLE,
                if (voskInstalled) "Offline recognition with the Vosk model you imported. Experimental: accuracy depends on the model, dialect and audio quality; large Arabic models can exhaust 4 GB phones."
                else "No speech model is imported yet.",
                if (voskInstalled) "" else "Settings > Import speech model (a free Vosk model .zip you download once)."),
            Capability("Photo motion (zoom / pan)", Mode.LOCAL,
                "A real Ken Burns camera move on still images. It is a motion effect, not AI-generated animation."),
            Capability("AI image generation", heavyMode,
                "Image diffusion models need roughly 2 GB or more just for weights plus working memory and a fast GPU/NPU runtime. This phone has $gb GB RAM shared with Android, so no model is loaded here.",
                heavyAlt),
            Capability("AI text-to-video (Wan 2.2, LTX)", heavyMode,
                "Wan2.2 5B's model card asks for at least 24 GB of VRAM, and LTX 2.3 lists 16 GB as its minimum. A phone has neither the memory nor the compute.",
                heavyAlt),
            Capability("AI image-to-video", heavyMode,
                "Same models and same limits as text-to-video.",
                heavyAlt)
        )
    }
}
