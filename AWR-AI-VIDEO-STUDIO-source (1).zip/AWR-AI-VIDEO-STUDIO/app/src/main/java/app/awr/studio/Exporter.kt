package app.awr.studio

import android.content.ContentValues
import android.content.Context
import android.graphics.Matrix
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.SpannableString
import android.text.Spanned
import android.text.style.AbsoluteSizeSpan
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import androidx.media3.common.C
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Brightness
import androidx.media3.effect.Contrast
import androidx.media3.effect.HslAdjustment
import androidx.media3.effect.MatrixTransformation
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.Presentation
import androidx.media3.effect.RgbAdjustment
import androidx.media3.effect.RgbMatrix
import androidx.media3.effect.TextOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import com.google.common.collect.ImmutableList
import java.io.File
import java.nio.ByteBuffer

val FILTERS = listOf("none", "cinematic", "noir", "warm", "cool", "vivid", "dream", "vintage", "neon")

@UnstableApi
private class GainProcessor(private val gain: Float) : BaseAudioProcessor() {
    override fun onConfigure(f: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (f.encoding != C.ENCODING_PCM_16BIT) throw AudioProcessor.UnhandledAudioFormatException(f)
        return f
    }
    override fun queueInput(input: ByteBuffer) {
        val out = replaceOutputBuffer(input.remaining())
        while (input.remaining() >= 2) {
            val v = (input.short * gain).toInt().coerceIn(-32768, 32767)
            out.putShort(v.toShort())
        }
        out.flip()
    }
}

@UnstableApi
private class SubtitleOverlay(private val cues: List<Cue>, private val sizePx: Int) : TextOverlay() {
    override fun getText(presentationTimeUs: Long): SpannableString {
        val cue = Subtitles.activeAt(cues, presentationTimeUs / 1000)
        val s = SpannableString(cue?.let { " ${it.text} " } ?: " ")
        if (cue != null) {
            s.setSpan(ForegroundColorSpan(0xFFFFFFFF.toInt()), 0, s.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            s.setSpan(BackgroundColorSpan(0xAA000000.toInt()), 0, s.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            s.setSpan(AbsoluteSizeSpan(sizePx), 0, s.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        return s
    }
    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings =
        OverlaySettings.Builder().setBackgroundFrameAnchor(0f, -0.72f).build()
}

@UnstableApi
object Exporter {
    private fun filterEffects(name: String): List<Effect> = when (name) {
        "cinematic" -> listOf(RgbAdjustment.Builder().setRedScale(1.08f).setBlueScale(0.94f).build(), Contrast(0.18f), HslAdjustment.Builder().adjustSaturation(-8f).build())
        "noir" -> listOf(HslAdjustment.Builder().adjustSaturation(-100f).build(), Contrast(0.35f), Brightness(-0.05f))
        "warm" -> listOf(RgbAdjustment.Builder().setRedScale(1.12f).setBlueScale(0.86f).build())
        "cool" -> listOf(RgbAdjustment.Builder().setRedScale(0.9f).setBlueScale(1.14f).build())
        "vivid" -> listOf(HslAdjustment.Builder().adjustSaturation(35f).build(), Contrast(0.12f))
        "dream" -> listOf(Brightness(0.08f), Contrast(-0.15f), HslAdjustment.Builder().adjustSaturation(-12f).build())
        "vintage" -> listOf(RgbAdjustment.Builder().setRedScale(1.1f).setBlueScale(0.84f).build(), HslAdjustment.Builder().adjustSaturation(-25f).build(), Contrast(-0.08f))
        "neon" -> listOf(RgbAdjustment.Builder().setRedScale(1.1f).setGreenScale(0.88f).setBlueScale(1.18f).build(), HslAdjustment.Builder().adjustSaturation(40f).build(), Contrast(0.2f))
        else -> emptyList()
    }

    private fun kenBurns(durUs: Long, zoomIn: Boolean) = MatrixTransformation { t ->
        val p = (t.toFloat() / durUs).coerceIn(0f, 1f)
        val s = if (zoomIn) 1f + 0.16f * p else 1.16f - 0.16f * p
        Matrix().apply { postScale(s, s) }
    }

    private fun fade(durUs: Long) = RgbMatrix { t, _ ->
        val edge = 400_000f
        val a = minOf(1f, t / edge, (durUs - t) / edge).coerceIn(0f, 1f)
        floatArrayOf(a, 0f, 0f, 0f, 0f, a, 0f, 0f, 0f, 0f, a, 0f, 0f, 0f, 0f, 1f)
    }

    fun canvas(ratio: String): Pair<Int, Int> = when (ratio) {
        "16:9" -> 1280 to 720
        "1:1" -> 720 to 720
        else -> 720 to 1280
    }

    /** Builds and starts the export. Must be called on the main thread. Returns the running Transformer. */
    fun start(
        ctx: Context, p: Project, out: File,
        onProgress: (Float) -> Unit, onDone: (Throwable?) -> Unit
    ): Transformer {
        val (w, h) = canvas(p.ratio)
        val keepAudio = p.keepClipAudio && p.clips.none { it.isImage } && p.voicePath == null && p.musicPath == null

        val items = p.clips.mapIndexed { i, c ->
            val uri = Uri.fromFile(File(c.path))
            val durUs = c.lenMs * 1000
            val mi = MediaItem.Builder().setUri(uri).apply {
                if (!c.isImage) setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder().setStartPositionMs(c.startMs).setEndPositionMs(c.endMs).build()
                )
            }.build()
            val fx = ArrayList<Effect>()
            if (c.isImage && c.kenBurns) fx += kenBurns(durUs, i % 2 == 0)
            fx += Presentation.createForWidthAndHeight(w, h, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP)
            if (p.fade) fx += fade(durUs)
            EditedMediaItem.Builder(mi).setEffects(Effects(emptyList(), fx)).apply {
                if (c.isImage) { setDurationUs(durUs); setFrameRate(30) }
                if (!keepAudio) setRemoveAudio(true)
            }.build()
        }
        val sequences = ArrayList<EditedMediaItemSequence>()
        sequences += EditedMediaItemSequence(items)

        fun audioItem(path: String, vol: Float) = EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(File(path))))
            .setEffects(Effects(listOf<AudioProcessor>(GainProcessor(vol)), emptyList())).build()
        p.voicePath?.let { sequences += EditedMediaItemSequence(listOf(audioItem(it, p.voiceVol))) }
        p.musicPath?.let { sequences += EditedMediaItemSequence(listOf(audioItem(it, p.musicVol)), true) }   // looping music

        val comp = ArrayList<Effect>()
        comp += filterEffects(p.filter)
        if (p.burnSubs && p.cues.isNotEmpty()) comp += OverlayEffect(ImmutableList.of(SubtitleOverlay(p.cues, h / 22)))

        val composition = Composition.Builder(sequences)
            .setEffects(Effects(emptyList(), comp)).build()

        val handler = Handler(Looper.getMainLooper())
        var finished = false
        val transformer = Transformer.Builder(ctx)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) { finished = true; onDone(null) }
                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) { finished = true; onDone(exportException) }
            }).build()
        out.parentFile?.mkdirs(); if (out.exists()) out.delete()
        transformer.start(composition, out.absolutePath)

        val holder = ProgressHolder()
        handler.post(object : Runnable {
            override fun run() {
                if (finished) return
                if (transformer.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE) onProgress(holder.progress / 100f)
                handler.postDelayed(this, 500)
            }
        })
        return transformer
    }

    /** Copies the finished MP4 into Movies/AWR Studio so it shows in the gallery. No permission needed on Android 10+. */
    fun saveToGallery(ctx: Context, file: File, displayName: String): Uri? {
        val v = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/AWR Studio")
        }
        val uri = ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v) ?: return null
        ctx.contentResolver.openOutputStream(uri)?.use { o -> file.inputStream().use { it.copyTo(o) } }
        return uri
    }
}
